import { useState, useEffect } from "react";
import NavBar from "../../components/navbar/NavBar";
import "./vehiculos.css";

const Vehiculos = () => {
  const [vehiculos, setVehiculos] = useState([]);
  const [resultadoBusqueda, setResultadoBusqueda] = useState([]);
  const [busquedaMarca, setBusquedaMarca] = useState("");
  const [busquedaId, setBusquedaId] = useState("");
  const [mostrandoResultados, setMostrandoResultados] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  
  
  const [formulario, setFormulario] = useState({
    marca: "",
    modelo: "",
    anio: "",
    color: "",
    placa: ""
  });
  const [modoEdicion, setModoEdicion] = useState(false);
  const [idEdicion, setIdEdicion] = useState(null);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);

  
  const fetchVehiculos = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("https://apimysql-pdb.onrender.com/Zautos/vehiculos/traer");
      if (!res.ok) throw new Error("Error al obtener vehículos");
      const data = await res.json();
      setVehiculos(Array.isArray(data) ? data : [data]);
      setMostrandoResultados(false);
      setBusquedaMarca("");
      setBusquedaId("");
    } catch (error) {
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  
  const crearVehiculo = async (vehiculoData) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("https://apimysql-pdb.onrender.com/Zautos/vehiculos/crear", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(vehiculoData),
      });

      if (!res.ok) throw new Error("Error al crear el vehículo");
      return { success: true };
    } catch (error) {
      setError(error.message);
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  };

  
  const buscarPorMarca = async () => {
    if (!busquedaMarca.trim()) return;
    
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`https://apimysql-pdb.onrender.com/Zautos/vehiculos/traerpormarca/${busquedaMarca}`);
      if (!res.ok) throw new Error("Error al buscar por marca");
      const data = await res.json();
      
      const resultados = Array.isArray(data) ? data : data ? [data] : [];
      setResultadoBusqueda(resultados);
      setMostrandoResultados(true);
    } catch (error) {
      setError(error.message);
      setResultadoBusqueda([]);
      setMostrandoResultados(true);
    } finally {
      setLoading(false);
    }
  };

  
  const buscarPorId = async () => {
    if (!busquedaId.trim()) return;
    
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`https://apimysql-pdb.onrender.com/Zautos/vehiculos/traerporid/${busquedaId}`);
      if (!res.ok) throw new Error("Error al buscar por ID");
      const data = await res.json();
      
      const resultados = data ? [data] : [];
      setResultadoBusqueda(resultados);
      setMostrandoResultados(true);
    } catch (error) {
      setError(error.message);
      setResultadoBusqueda([]);
      setMostrandoResultados(true);
    } finally {
      setLoading(false);
    }
  };

  
  const actualizarVehiculo = async (id, vehiculoData) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`https://apimysql-pdb.onrender.com/Zautos/vehiculos/actualizar/${id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(vehiculoData),
      });

      if (!res.ok) throw new Error("Error al actualizar el vehículo");
      return { success: true };
    } catch (error) {
      setError(error.message);
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  };

  
  const eliminarVehiculo = async (id) => {
    if (!window.confirm("¿Está seguro que desea eliminar este vehículo?")) return;
    
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`https://apimysql-pdb.onrender.com/Zautos/vehiculos/eliminar/${id}`, {
        method: "DELETE",
      });

      if (!res.ok) throw new Error("Error al eliminar el vehículo");
      await fetchVehiculos();
      return { success: true };
    } catch (error) {
      setError(error.message);
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  };

  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    
    if (!formulario.marca || !formulario.modelo || !formulario.anio || !formulario.color || !formulario.placa) {
      setError("Todos los campos son obligatorios");
      return;
    }

    let result;
    if (modoEdicion) {
      result = await actualizarVehiculo(idEdicion, formulario);
    } else {
      result = await crearVehiculo(formulario);
    }

    if (result.success) {
      await fetchVehiculos();
      setFormulario({
        marca: "",
        modelo: "",
        anio: "",
        color: "",
        placa: ""
      });
      setModoEdicion(false);
      setIdEdicion(null);
      setMostrarFormulario(false);
      setError(null);
    }
  };

  
  const iniciarEdicion = (vehiculo) => {
    setFormulario({
      marca: vehiculo.marca,
      modelo: vehiculo.modelo,
      anio: vehiculo.anio,
      color: vehiculo.color,
      placa: vehiculo.placa
    });
    setModoEdicion(true);
    setIdEdicion(vehiculo.id_vehiculo);
    setMostrarFormulario(true);
    setError(null);
  };

 
  const cancelarEdicion = () => {
    setFormulario({
      marca: "",
      modelo: "",
      anio: "",
      color: "",
      placa: ""
    });
    setModoEdicion(false);
    setIdEdicion(null);
    setMostrarFormulario(false);
    setError(null);
  };

  useEffect(() => {
    fetchVehiculos();
  }, []);

  
  const renderTablaResultados = (vehiculos) => {
    if (loading) return <p>Cargando...</p>;
    if (error) return <p className="error">Error: {error}</p>;
    if (vehiculos.length === 0) return <p>No se encontraron vehículos</p>;

    return (
      <table className="vehiculos-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Marca</th>
            <th>Modelo</th>
            <th>Año</th>
            <th>Color</th>
            <th>Placa</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {vehiculos.map((veh) => (
            <tr key={veh.id_vehiculo}>
              <td>{veh.id_vehiculo}</td>
              <td>{veh.marca}</td>
              <td>{veh.modelo}</td>
              <td>{veh.anio}</td>
              <td>{veh.color}</td>
              <td>{veh.placa}</td>
              <td>
                <button 
                  onClick={() => iniciarEdicion(veh)}
                  disabled={loading}
                >
                  Editar
                </button>
                <button 
                  onClick={() => eliminarVehiculo(veh.id_vehiculo)}
                  disabled={loading}
                >
                  Eliminar
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    );
  };

  return (
    <>
      <NavBar />
      <div className="vehiculos-container">
        <h1>Gestión de Vehículos</h1>
        
        
        {!mostrarFormulario && (
          <button 
            className="btn-nuevo"
            onClick={() => {
              setModoEdicion(false);
              setFormulario({
                marca: "",
                modelo: "",
                anio: "",
                color: "",
                placa: ""
              });
              setMostrarFormulario(true);
            }}
            disabled={loading}
          >
            Nuevo Vehículo
          </button>
        )}

        
        {mostrarFormulario && (
          <div className="formulario-container">
            <h2>{modoEdicion ? "Editar Vehículo" : "Crear Nuevo Vehículo"}</h2>
            
            {error && <p className="error">{error}</p>}
            
            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label>Marca:</label>
                <input
                  type="text"
                  value={formulario.marca}
                  onChange={(e) => setFormulario({...formulario, marca: e.target.value})}
                  required
                  disabled={loading}
                />
              </div>

              <div className="form-group">
                <label>Modelo:</label>
                <input
                  type="text"
                  value={formulario.modelo}
                  onChange={(e) => setFormulario({...formulario, modelo: e.target.value})}
                  required
                  disabled={loading}
                />
              </div>

              <div className="form-group">
                <label>Año:</label>
                <input
                  type="number"
                  value={formulario.anio}
                  onChange={(e) => setFormulario({...formulario, anio: e.target.value})}
                  required
                  disabled={loading}
                />
              </div>

              <div className="form-group">
                <label>Color:</label>
                <input
                  type="text"
                  value={formulario.color}
                  onChange={(e) => setFormulario({...formulario, color: e.target.value})}
                  required
                  disabled={loading}
                />
              </div>

              <div className="form-group">
                <label>Placa:</label>
                <input
                  type="text"
                  value={formulario.placa}
                  onChange={(e) => setFormulario({...formulario, placa: e.target.value})}
                  required
                  disabled={loading}
                />
              </div>

              <div className="form-buttons">
                <button type="submit" disabled={loading}>
                  {loading ? "Procesando..." : (modoEdicion ? "Actualizar" : "Crear")}
                </button>
                <button
                  type="button"
                  onClick={cancelarEdicion}
                  disabled={loading}
                >
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        )}

       
        <div className="busqueda-container">
          <div className="busqueda-grupo">
            <h3>Buscar por ID</h3>
            <div className="busqueda-input">
              <input
                type="number"
                value={busquedaId}
                onChange={(e) => setBusquedaId(e.target.value)}
                placeholder="Ingrese ID del vehículo"
                disabled={loading}
              />
              <button onClick={buscarPorId} disabled={loading}>
                Buscar
              </button>
            </div>
          </div>

          <div className="busqueda-grupo">
            <h3>Buscar por Marca</h3>
            <div className="busqueda-input">
              <input
                type="text"
                value={busquedaMarca}
                onChange={(e) => setBusquedaMarca(e.target.value)}
                placeholder="Ingrese marca del vehículo"
                disabled={loading}
              />
              <button onClick={buscarPorMarca} disabled={loading}>
                Buscar
              </button>
            </div>
          </div>

          <button 
            onClick={fetchVehiculos} 
            className="btn-mostrar-todos"
            disabled={loading}
          >
            Mostrar todos
          </button>
        </div>

       
        <div className="resultados-container">
          {mostrandoResultados ? (
            <>
              <h2>Resultados de la búsqueda</h2>
              {renderTablaResultados(resultadoBusqueda)}
            </>
          ) : (
            <>
              <h2>Todos los vehículos</h2>
              {renderTablaResultados(vehiculos)}
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default Vehiculos;