import NavBar from "../../components/navbar/NavBar";
import "./inicio.css"
const Inicio = () => {
  return (
    <div className="body1">
      <NavBar />
      <section className="cover-container">
      <div className="overlay"></div>
      <div className="content">
        <h1 className="main-title">Todo comienza con FZautos</h1>
        <p className="subtitle">Descubre la experiencia de conducir</p>
        <button className="cta-button">Explora nuestros autos</button>
      </div>
    </section>
    </div>
  );
};
export default Inicio;