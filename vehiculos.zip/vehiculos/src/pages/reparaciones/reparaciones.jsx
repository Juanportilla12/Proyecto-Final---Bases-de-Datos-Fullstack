import { useState, useEffect } from "react";
import NavBar from "../../components/navbar/NavBar";

const Reparaciones = () => {
    const [reparaciones, setReparaciones] = useState([]);
    const [resultadoBusqueda, setResultadoBusqueda] = useState([]);
    const [busquedaId, setBusquedaId] = useState("");
    const [mostrandoResultados, setMostrandoResultados] = useState(false);

    
    const [formAgregar, setFormAgregar] = useState({
        id_vehiculo: "",
        id_servicio: "",
        fecha_servicio: "",
        costo_total: "",
        mecanico: ""
    });

    
    const [formEditar, setFormEditar] = useState({
        id_reparacion: "",
        id_vehiculo: "",
        id_servicio: "",
        fecha_servicio: "",
        costo_total: "",
        mecanico: ""
    });

    const fetchReparaciones = async () => {
        try {
            const res = await fetch("https://apimysql-pdb.onrender.com/Zautos/reparaciones/traer");
            const data = await res.json();
            setReparaciones(data);
            setMostrandoResultados(false);
        } catch (error) {
            console.error("Error al obtener reparaciones:", error);
        }
    };

    const buscarPorId = async () => {
        try {
            if (!busquedaId.trim()) return fetchReparaciones();
            const res = await fetch(`https://apimysql-pdb.onrender.com/Zautos/reparaciones/traerporid/${busquedaId}`);
            const data = await res.json();
            setResultadoBusqueda(data ? [data] : []);
            setMostrandoResultados(true);
        } catch (error) {
            console.error("Error al buscar reparación:", error);
        }
    };

    const handleEliminar = async (id) => {
        if (!window.confirm("¿Estás seguro de eliminar esta reparación?")) return;

        try {
            const res = await fetch(`https://apimysql-pdb.onrender.com/Zautos/reparaciones/eliminar/${id}`, {
                method: "DELETE"
            });

            if (!res.ok) throw new Error("Error al eliminar");

            fetchReparaciones();
        } catch (error) {
            console.error("Error al eliminar la reparación:", error);
            alert("Error al eliminar la reparación");
        }
    };

    
    const limpiarBusqueda = () => {
        setBusquedaId("");
        setResultadoBusqueda([]);
        setMostrandoResultados(false);
    };

    
    const handleChange = (setter) => (e) => {
        setter(prev => ({ ...prev, [e.target.name]: e.target.value }));
    };

    
    const handleAgregar = async (e) => {
        e.preventDefault();

        try {
            const datos = {
                ...formAgregar,
                costo_total: Number(formAgregar.costo_total)
            };

            const res = await fetch("https://apimysql-pdb.onrender.com/Zautos/reparaciones/crear", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(datos)
            });

            if (!res.ok) throw new Error(await res.text());

            fetchReparaciones();
            setFormAgregar({
                id_vehiculo: "",
                id_servicio: "",
                fecha_servicio: "",
                costo_total: "",
                mecanico: ""
            });

            alert("Reparación agregada con éxito");
        } catch (error) {
            console.error("Error al agregar reparación:", error);
            alert("Error al agregar reparación: " + error.message);
        }
    };

    
    const prepararEdicion = (rep) => {
        
        const fecha = new Date(rep.fecha_servicio);
        const fechaFormateada = fecha.toISOString().split('T')[0];

        setFormEditar({
            id_reparacion: rep.id_reparacion,
            id_vehiculo: rep.id_vehiculo,
            id_servicio: rep.id_servicio,
            fecha_servicio: fechaFormateada,
            costo_total: rep.costo_total,
            mecanico: rep.mecanico
        });
    };

    
    const handleEditar = async (e) => {
        e.preventDefault();

        try {
            const datos = {
                ...formEditar,
                costo_total: Number(formEditar.costo_total)
            };

            const res = await fetch(`https://apimysql-pdb.onrender.com/Zautos/reparaciones/actualizar/${formEditar.id_reparacion}`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(datos)
            });

            if (!res.ok) throw new Error(await res.text());

            fetchReparaciones();
            setFormEditar({
                id_reparacion: "",
                id_vehiculo: "",
                id_servicio: "",
                fecha_servicio: "",
                costo_total: "",
                mecanico: ""
            });

            alert("Reparación actualizada con éxito");
        } catch (error) {
            console.error("Error al editar reparación:", error);
            alert("Error al editar reparación: " + error.message);
        }
    };

  
    useEffect(() => { fetchReparaciones(); }, []);

    return (
        <>
            <NavBar />
            <div>
                <h1>Reparaciones</h1>

                
                <div>
                    <h2>Buscar Reparación</h2>
                    <input
                        value={busquedaId}
                        onChange={(e) => setBusquedaId(e.target.value)}
                        placeholder="Buscar por ID"
                    />
                    <button onClick={buscarPorId}>Buscar</button>
                    <button onClick={limpiarBusqueda}>Limpiar</button>
                </div>

                
                <div>
                    <h2>Agregar Reparación</h2>
                    <form onSubmit={handleAgregar}>
                        <input
                            name="id_vehiculo"
                            value={formAgregar.id_vehiculo}
                            onChange={handleChange(setFormAgregar)}
                            placeholder="ID Vehículo"
                            required
                        />
                        <input
                            name="id_servicio"
                            value={formAgregar.id_servicio}
                            onChange={handleChange(setFormAgregar)}
                            placeholder="ID Servicio"
                            required
                        />
                        <input
                            type="date"
                            name="fecha_servicio"
                            value={formAgregar.fecha_servicio}
                            onChange={handleChange(setFormAgregar)}
                            required
                        />
                        <input
                            type="number"
                            name="costo_total"
                            value={formAgregar.costo_total}
                            onChange={handleChange(setFormAgregar)}
                            placeholder="Costo Total"
                            step="0.01"
                            min="0"
                            required
                        />
                        <input
                            name="mecanico"
                            value={formAgregar.mecanico}
                            onChange={handleChange(setFormAgregar)}
                            placeholder="Mecánico"
                            required
                        />
                        <button type="submit">Agregar</button>
                    </form>
                </div>

                
                {formEditar.id_reparacion && (
                    <div>
                        <h2>Editar Reparación</h2>
                        <form onSubmit={handleEditar}>
                            <input
                                name="id_vehiculo"
                                value={formEditar.id_vehiculo}
                                onChange={handleChange(setFormEditar)}
                                placeholder="ID Vehículo"
                                required
                            />
                            <input
                                name="id_servicio"
                                value={formEditar.id_servicio}
                                onChange={handleChange(setFormEditar)}
                                placeholder="ID Servicio"
                                required
                            />
                            <input
                                type="date"
                                name="fecha_servicio"
                                value={formEditar.fecha_servicio}
                                onChange={handleChange(setFormEditar)}
                                required
                            />
                            <input
                                type="number"
                                name="costo_total"
                                value={formEditar.costo_total}
                                onChange={handleChange(setFormEditar)}
                                placeholder="Costo Total"
                                step="0.01"
                                min="0"
                                required
                            />
                            <input
                                name="mecanico"
                                value={formEditar.mecanico}
                                onChange={handleChange(setFormEditar)}
                                placeholder="Mecánico"
                                required
                            />
                            <button type="submit">Actualizar</button>
                            <button type="button" onClick={() => setFormEditar({
                                id_reparacion: "",
                                id_vehiculo: "",
                                id_servicio: "",
                                fecha_servicio: "",
                                costo_total: "",
                                mecanico: ""
                            })}>
                                Cancelar
                            </button>
                        </form>
                    </div>
                )}

                
                {mostrandoResultados ? (
                    <div>
                        <h2>Resultados de búsqueda</h2>
                        <table border="1">
                            <thead>
                                <tr>
                                    <th>ID Reparación</th>
                                    <th>ID Vehículo</th>
                                    <th>ID Servicio</th>
                                    <th>Fecha</th>
                                    <th>Costo Total</th>
                                    <th>Mecánico</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                {resultadoBusqueda.map(rep => (
                                    <tr key={rep.id_reparacion}>
                                        <td>{rep.id_reparacion}</td>
                                        <td>{rep.id_vehiculo}</td>
                                        <td>{rep.id_servicio}</td>
                                        <td>{new Date(rep.fecha_servicio).toLocaleDateString()}</td>
                                        <td>${rep.costo_total}</td>
                                        <td>{rep.mecanico}</td>
                                        <td>
                                            <button onClick={() => prepararEdicion(rep)}>Editar</button>
                                            <button onClick={() => handleEliminar(rep.id_reparacion)}>Eliminar</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <div>
                        <h2>Lista de Reparaciones</h2>
                        <table border="1">
                            <thead>
                                <tr>
                                    <th>ID Reparación</th>
                                    <th>ID Vehículo</th>
                                    <th>ID Servicio</th>
                                    <th>Fecha</th>
                                    <th>Costo Total</th>
                                    <th>Mecánico</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reparaciones.map(rep => (
                                    <tr key={rep.id_reparacion}>
                                        <td>{rep.id_reparacion}</td>
                                        <td>{rep.id_vehiculo}</td>
                                        <td>{rep.id_servicio}</td>
                                        <td>{new Date(rep.fecha_servicio).toLocaleDateString()}</td>
                                        <td>${rep.costo_total}</td>
                                        <td>{rep.mecanico}</td>
                                        <td>
                                            <button onClick={() => prepararEdicion(rep)}>Editar</button>
                                            <button onClick={() => handleEliminar(rep.id_reparacion)}>Eliminar</button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </>
    );
};

export default Reparaciones;