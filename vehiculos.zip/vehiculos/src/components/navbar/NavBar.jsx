import { Link } from 'react-router-dom';
import './NavBar.css';

const NavBar = () => {
  return (
    <nav className="navbar">
      <h1 className="navbar-logo">ZAutos</h1>
      <ul className="navbar-links">
        <li><Link to="/">Inicio</Link></li>
        <li><Link to="/Carros">Carros</Link></li>
        <li><Link to="/Reparaciones">Reparaciones</Link></li>
        <li><Link to="/Servicios">Servicios</Link></li>
        <li><Link to="/Vehiculos">Vehiculos</Link></li>
      </ul>
    </nav>
  );
};
export default NavBar;