import { useState, useEffect } from "react";
import NavBar from "../../components/navbar/NavBar";
import "./carros.css"

const carros = () => {
  const [carros, setCarros] = useState([]);
  const [busqueda, setBusqueda] = useState({
    marca: "",
    anio: ""
  });
  const [resultadosBusqueda, setResultadosBusqueda] = useState([]);
  const [formAgregar, setFormAgregar] = useState({
    marca: "", 
    modelo: "",
    anio: "",
    color: "",
    tipo: "",
    id_motor: "",
    id_propietario: "" 
  });
  const [formEditar, setFormEditar] = useState({
    _id: "",
    marca: "", 
    modelo: "",
    anio: "",
    color: "",
    tipo: "",
    id_motor: "",
    id_propietario: ""  
  });

  const fetchCarros = async () => {
    try {
      const res = await fetch("https://mongoapi-pdb.onrender.com/api/carros/obtenerTodos");
      const data = await res.json();
      setCarros(data);
    } catch (error) {
      console.error("Error al obtener carros:", error);
    }
  };

  useEffect(() => { fetchCarros(); }, []);

  const handleChange = (setter) => (e) => {
    setter(prev => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleAgregar = async (e) => {
    e.preventDefault();
    
    
    const datos = {
      ...formAgregar,
      anio: Number(formAgregar.anio),
      tipo: formAgregar.tipo === "Crulser" ? "Cruiser" : formAgregar.tipo,
      color: formAgregar.color === "Megro" ? "Negro" : formAgregar.color
    };

    try {
      const res = await fetch("https://mongoapi-pdb.onrender.com/api/carros/addCarro", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos)
      });

      if (!res.ok) throw new Error(await res.text());
      
      fetchCarros();
      setFormAgregar({ 
        marca: "", 
        modelo: "", 
        anio: "", 
        color: "", 
        tipo: "", 
        id_motor: "", 
        id_propietario: "" 
      });
    } catch (error) {
      console.error("Error al agregar carro:", error);
      alert("Error al agregar carro: " + error.message);
    }
  };

  const handleEditar = async (e) => {
    e.preventDefault();
    
    const datos = {
      ...formEditar,
      anio: Number(formEditar.anio),
      tipo: formEditar.tipo === "Crulser" ? "Cruiser" : formEditar.tipo,
      color: formEditar.color === "Megro" ? "Negro" : formEditar.color
    };

    try {
      const res = await fetch(`https://mongoapi-pdb.onrender.com/api/carros/editarCarro/${formEditar._id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(datos)
      });

      if (!res.ok) throw new Error(await res.text());
      
      fetchCarros();
      setFormEditar({ 
        _id: "", 
        marca: "", 
        modelo: "", 
        anio: "", 
        color: "", 
        tipo: "", 
        id_motor: "", 
        id_propietario: "" 
      });
    } catch (error) {
      console.error("Error al editar carro:", error);
      alert("Error al editar carro: " + error.message);
    }
  };

  const handleEliminar = async (id) => {
    if (!window.confirm("¿Estás seguro de eliminar este carro?")) return;
    
    try {
      const res = await fetch(`https://mongoapi-pdb.onrender.com/api/carros/eliminarCarro/${id}`, {
        method: "DELETE"
      });

      if (!res.ok) throw new Error(await res.text());
      
      fetchCarros();
    } catch (error) {
      console.error("Error al eliminar carro:", error);
      alert("Error al eliminar carro: " + error.message);
    }
  };

  const buscarCarros = async () => {
    try {
      const params = new URLSearchParams();
      if (busqueda.marca) params.append('marca', busqueda.marca);
      if (busqueda.anio) params.append('año', busqueda.anio);
      
      const res = await fetch(`https://mongoapi-pdb.onrender.com/api/carros/buscarCarro?${params}`);
      const data = await res.json();
      setResultadosBusqueda(data);
    } catch (error) {
      console.error("Error al buscar carros:", error);
    }
  };

  
  const limpiarBusqueda = () => {
    setBusqueda({
      marca: "",
      anio: ""
    });
    setResultadosBusqueda([]);
  };

  const prepararEdicion = (carro) => {
    setFormEditar({
      ...carro,
      anio: carro.anio.toString()
    });
  };

  return (
    <>
      <NavBar />
      <div>
        <h1>Carros</h1>
        
        
        <div>
          <h2>Buscar Carros</h2>
          <input name="marca" value={busqueda.marca} onChange={handleChange(setBusqueda)} placeholder="Marca" />
          <input name="anio" value={busqueda.anio} onChange={handleChange(setBusqueda)} placeholder="Año" />
          <button onClick={buscarCarros}>Buscar</button>
          <button onClick={limpiarBusqueda}>Limpiar</button>
        </div>

        
        {resultadosBusqueda.length > 0 && (
          <div>
            <h3>Resultados</h3>
            <table border="1">
              <thead>
                <tr>
                  <th>Marca</th>
                  <th>Modelo</th>
                  <th>Año</th>
                  <th>Color</th>
                  <th>Tipo</th>
                  <th>ID Motor</th>
                  <th>ID Propietario</th>
                </tr>
              </thead>
              <tbody>
                {resultadosBusqueda.map(c => (
                  <tr key={c._id}>
                    <td>{c.marca}</td>
                    <td>{c.modelo}</td>
                    <td>{c.anio}</td>
                    <td>{c.color}</td>
                    <td>{c.tipo}</td>
                    <td>{c.id_motor}</td>
                    <td>{c.id_propietario}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

       
        <h2>Lista de Carros</h2>
        <table border="1">
          <thead>
            <tr>
              <th>Marca</th>
              <th>Modelo</th>
              <th>Año</th>
              <th>Color</th>
              <th>Tipo</th>
              <th>ID Motor</th>
              <th>ID Propietario</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {carros.map(c => (
              <tr key={c._id}>
                <td>{c.marca}</td>
                <td>{c.modelo}</td>
                <td>{c.anio}</td>
                <td>{c.color}</td>
                <td>{c.tipo}</td>
                <td>{c.id_motor}</td>
                <td>{c.id_propietario}</td>
                <td>
                  <button onClick={() => prepararEdicion(c)}>Editar</button>
                  <button onClick={() => handleEliminar(c._id)}>Eliminar</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        
        <h2>Agregar Vehículo</h2>
        <form onSubmit={handleAgregar}>
          <input name="marca" value={formAgregar.marca} onChange={handleChange(setFormAgregar)} placeholder="Marca" required />
          <input name="modelo" value={formAgregar.modelo} onChange={handleChange(setFormAgregar)} placeholder="Modelo" required />
          <input type="number" name="anio" value={formAgregar.anio} onChange={handleChange(setFormAgregar)} placeholder="Año" min="1900" max={new Date().getFullYear() + 1} required />
          <input name="color" value={formAgregar.color} onChange={handleChange(setFormAgregar)} placeholder="Color" required />
          <input name="tipo" value={formAgregar.tipo} onChange={handleChange(setFormAgregar)} placeholder="Tipo" required />
          <input name="id_motor" value={formAgregar.id_motor} onChange={handleChange(setFormAgregar)} placeholder="ID Motor" required pattern="[0-9a-fA-F]{24}" title="ID de 24 caracteres hexadecimal" />
          <input name="id_propietario" value={formAgregar.id_propietario} onChange={handleChange(setFormAgregar)} placeholder="ID Propietario" required pattern="[0-9a-fA-F]{24}" title="ID de 24 caracteres hexadecimal" />
          <button type="submit">Agregar</button>
        </form>

        
        {formEditar._id && (
          <>
            <h2>Editar Vehículo</h2>
            <form onSubmit={handleEditar}>
              <input name="marca" value={formEditar.marca} onChange={handleChange(setFormEditar)} placeholder="Marca" required />
              <input name="modelo" value={formEditar.modelo} onChange={handleChange(setFormEditar)} placeholder="Modelo" required />
              <input type="number" name="anio" value={formEditar.anio} onChange={handleChange(setFormEditar)} placeholder="Año" min="1900" max={new Date().getFullYear() + 1} required />
              <input name="color" value={formEditar.color} onChange={handleChange(setFormEditar)} placeholder="Color" required />
              <input name="tipo" value={formEditar.tipo} onChange={handleChange(setFormEditar)} placeholder="Tipo" required />
              <input name="id_motor" value={formEditar.id_motor} onChange={handleChange(setFormEditar)} placeholder="ID Motor" required pattern="[0-9a-fA-F]{24}" title="ID de 24 caracteres hexadecimal" />
              <input name="id_propietario" value={formEditar.id_propietario} onChange={handleChange(setFormEditar)} placeholder="ID Propietario" required pattern="[0-9a-fA-F]{24}" title="ID de 24 caracteres hexadecimal" />
              <button type="submit">Actualizar</button>
              <button type="button" onClick={() => setFormEditar({ _id: "", marca: "", modelo: "", anio: "", color: "", tipo: "", id_motor: "", id_propietario: "" })}>
                Cancelar
              </button>
            </form>
          </>
        )}
      </div>
    </>
  );
};

export default carros;