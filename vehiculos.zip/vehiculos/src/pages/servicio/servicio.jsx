import { useState, useEffect } from "react";
import NavBar from "../../components/navbar/NavBar";
import "./servicio.css";

const Servicios = () => {
  const [servicios, setServicios] = useState([]);
  const [resultadoBusqueda, setResultadoBusqueda] = useState([]);
  const [busquedaId, setBusquedaId] = useState("");
  const [mostrandoResultados, setMostrandoResultados] = useState(false);
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [servicioEditando, setServicioEditando] = useState(null);
  const [error, setError] = useState(null);
  const [formData, setFormData] = useState({
    nombre: "",
    descripcion: "",
    precio: ""
  });

  
  const API_BASE_URL = "https://apimysql-pdb.onrender.com";

  
  const fetchServicios = async () => {
    setError(null);
    try {
      const res = await fetch(`${API_BASE_URL}/Zautos/servicios/traer`);
      
      if (!res.ok) {
        throw new Error(`Error ${res.status}: ${res.statusText}`);
      }
      
      const data = await res.json();
      setServicios(data);
      setMostrandoResultados(false);
    } catch (error) {
      console.error("Error al obtener servicios:", error);
      setError("No se pudieron cargar los servicios. Intente nuevamente más tarde.");
      setServicios([]);
    }
  };

  
  const buscarPorId = async () => {
    setError(null);
    if (!busquedaId.trim()) {
      return fetchServicios();
    }
    
    try {
      const res = await fetch(`${API_BASE_URL}/Zautos/servicios/traerporid/${busquedaId}`);
      
      if (!res.ok) {
        if (res.status === 404) {
          setResultadoBusqueda([]);
          setMostrandoResultados(true);
          setError("No se encontró el servicio con el ID proporcionado.");
          return;
        }
        throw new Error(`Error ${res.status}: ${res.statusText}`);
      }
      
      const data = await res.json();
      setResultadoBusqueda(data ? [data] : []);
      setMostrandoResultados(true);
    } catch (error) {
      console.error("Error al buscar por ID:", error);
      setError("No se pudo realizar la búsqueda. Verifique la conexión e intente nuevamente.");
      setResultadoBusqueda([]);
      setMostrandoResultados(true);
    }
  };

  
  const handleEliminar = async (id) => {
    if (!window.confirm("¿Estás seguro de eliminar este servicio?")) return;
    
    try {
      const response = await fetch(`${API_BASE_URL}/Zautos/servicios/eliminar/${id}`, { 
        method: "DELETE" 
      });
      
      if (!response.ok) {
        throw new Error(`Error ${response.status}: ${response.statusText}`);
      }
      
      alert("Servicio eliminado exitosamente");
      fetchServicios();
    } catch (error) {
      console.error("Error al eliminar:", error);
      alert(`Error al eliminar el servicio: ${error.message}`);
    }
  };

  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    const url = servicioEditando 
      ? `${API_BASE_URL}/Zautos/servicios/actualizar/${servicioEditando}`
      : `${API_BASE_URL}/Zautos/servicios/crear`;
      
    const method = servicioEditando ? "PUT" : "POST";

    try {
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ 
          error: `Error ${response.status}: ${response.statusText}` 
        }));
        throw new Error(errorData.error || "Error al procesar la solicitud");
      }

      alert(servicioEditando 
        ? "Servicio actualizado exitosamente" 
        : "Servicio creado exitosamente");
      setMostrarFormulario(false);
      fetchServicios();
    } catch (error) {
      console.error("Error en submit:", error);
      alert(`Error: ${error.message}`);
    }
  };

  
  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  
  const handleEditar = (servicio) => {
    setServicioEditando(servicio.id_servicio);
    setFormData({
      nombre: servicio.nombre,
      descripcion: servicio.descripcion,
      precio: servicio.precio
    });
    setMostrarFormulario(true);
  };

  
  const resetForm = () => {
    setServicioEditando(null);
    setFormData({
      nombre: "",
      descripcion: "",
      precio: ""
    });
  };

  useEffect(() => { 
    fetchServicios(); 
  }, []);

  return (
    <>
      <NavBar />
      <div className="servicios-container">
        <h1>Servicios</h1>
        
        <div className="servicios-actions">
          <div className="search-container">
            <input 
              value={busquedaId}
              onChange={(e) => setBusquedaId(e.target.value)}
              placeholder="Buscar por ID"
            />
            <button onClick={buscarPorId}>Buscar</button>
            <button onClick={fetchServicios}>Mostrar todos</button>
          </div>
          
          <button 
            onClick={() => {
              resetForm();
              setMostrarFormulario(true);
            }}
            className="add-button"
          >
            Agregar Servicio
          </button>
        </div>

        {mostrarFormulario && (
          <div className="form-modal">
            <div className="form-content">
              <h2>{servicioEditando ? "Editar Servicio" : "Nuevo Servicio"}</h2>
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label>Nombre:</label>
                  <input
                    type="text"
                    name="nombre"
                    value={formData.nombre}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Descripción:</label>
                  <textarea
                    name="descripcion"
                    value={formData.descripcion}
                    onChange={handleChange}
                    required
                  />
                </div>
                
                <div className="form-group">
                  <label>Precio:</label>
                  <input
                    type="number"
                    name="precio"
                    value={formData.precio}
                    onChange={handleChange}
                    required
                    min="0"
                    step="0.01"
                  />
                </div>
                
                <div className="form-buttons">
                  <button type="submit">Guardar</button>
                  <button 
                    type="button" 
                    onClick={() => setMostrarFormulario(false)}
                  >
                    Cancelar
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {error && (
          <div className="error-message">
            {error}
          </div>
        )}

        {mostrandoResultados ? (
          <ServiciosTable 
            servicios={resultadoBusqueda} 
            onEdit={handleEditar}
            onDelete={handleEliminar}
            showActions={true}
          />
        ) : (
          <ServiciosTable 
            servicios={servicios} 
            onEdit={handleEditar}
            onDelete={handleEliminar}
            showActions={true}
          />
        )}
      </div>
    </>
  );
};


const ServiciosTable = ({ servicios, onEdit, onDelete, showActions }) => {
  if (servicios.length === 0) {
    return <p className="no-results">No hay servicios para mostrar</p>;
  }

  return (
    <table className="servicios-table">
      <thead>
        <tr>
          <th>ID Servicio</th>
          <th>Nombre</th>
          <th>Descripción</th>
          <th>Precio</th>
          {showActions && <th>Acciones</th>}
        </tr>
      </thead>
      <tbody>
        {servicios.map(serv => (
          <tr key={serv.id_servicio}>
            <td>{serv.id_servicio}</td>
            <td>{serv.nombre}</td>
            <td>{serv.descripcion}</td>
            <td>${serv.precio}</td>
            {showActions && (
              <td className="actions-cell">
                <button 
                  onClick={() => onEdit(serv)}
                  className="edit-button"
                >
                  Editar
                </button>
                <button 
                  onClick={() => onDelete(serv.id_servicio)}
                  className="delete-button"
                >
                  Eliminar
                </button>
              </td>
            )}
          </tr>
        ))}
      </tbody>
    </table>
  );
};

export default Servicios;