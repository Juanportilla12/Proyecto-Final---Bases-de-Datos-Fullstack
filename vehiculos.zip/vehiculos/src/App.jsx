import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";

import NavBar from "./components/navbar/NavBar";

import Inicio from "./pages/inicio/inicio"
import Carros from "./pages/carros/carros"
import Reparaciones from "./pages/reparaciones/reparaciones";
import Servicios from "./pages/servicio/servicio"
import Vehiculos from "./pages/vehiculos/vehiculos";




const router = createBrowserRouter([
  {
    path: "/",
    element: <Inicio/>,
  },
  {
    path: "/NavBar",
    element: <NavBar/>,
  },
  {
    path: "/Carros",
    element: <Carros/>
  },
  {
    path: "/Reparaciones",
    element: <Reparaciones/>
  },
  {
    path: "/Servicios",
    element: <Servicios/>
  },
  {
    path: "/Vehiculos",
    element: <Vehiculos/>
  }
]);

function App() {
  return (
    <React.Fragment>
      <RouterProvider router={router} />
    </React.Fragment>
  );
}

export default App;
